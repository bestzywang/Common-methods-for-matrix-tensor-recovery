cd subroutines
mex compute_current_estimate.c  
mex compute_current_estimate_wgrad.c 
mex compute_current_estimate_vec.c 
mex compute_current_estimate_vec_wjac.c 
mex compute_sparsity_pattern_jac.c 
cd ..