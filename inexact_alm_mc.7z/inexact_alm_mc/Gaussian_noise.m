function [noise] = Gaussian_noise(sigma_1,model)
    noise_row = 150;
    noise_col = 300;
    noise = zeros( noise_row, noise_col );
    p = 0.9;
    mu = [ 0 0 ];
    sigma = [ 10*sigma_1 sigma_1 ];
    flag = binornd( 1, p, [ noise_row, noise_col ] );
    switch model
        case 'GW'
            for i = 1 : noise_row
                for j = 1:noise_col                 
                        noise( i,j ) = 0 + sigma_1 * randn( 1, 1 );                   
                end
            end
        case 'SB'
            for i = 1 : noise_row
                for j = 1:noise_col
                    if flag( i,j ) == 0
                        noise( i,j ) = 0 + sigma_1 * randn( 1, 1 );
                    else
                        noise( i,j ) = 0;
                    end
                end
            end
        case 'GM'
            for i = 1 : noise_row
                for j = 1:noise_col
                    if flag( i,j ) == 0
                        noise( i,j ) = mu( 1 ) + sigma( 1 ) * randn( 1, 1 );
                    else
                        noise( i,j ) = mu( 2 ) + sigma( 2 ) * randn( 1, 1 );
                    end
                end
            end
    end
end