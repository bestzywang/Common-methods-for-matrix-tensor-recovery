% Description: Implementation of Fig. 9 in [1]. 
% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                  "Robust Estimation of Structured Covariance Matrix for
%                   Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                   vol. 64, no. 14, pp. 3576-3590, July 2016.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun   
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.

%%
clc
clear

K = 100;


m = 10; % number of spikes
% generate random signal basis
A_signal = orth(randn(K));
A_signal = A_signal(:,1:m);

p = 99*rand(m,1)+ 1;
sigma = 1;
R_true = A_signal*diag(p)*A_signal'+sigma*eye(K);
R_true = R_true/trace(R_true);
Ec_true = orth(A_signal); % true signal subspace

Ngrid = 105:5:150;
repts = 10;

iter = 0;

tol = 1e-7;
for N = Ngrid
    iter = iter + 1;
    fprintf('sample number: %d\n',N);
    for t = 1:repts;
        % Generate samples
        v = chi2rnd(1,[1,N]);
        x = mvnrnd(zeros(K,1),R_true,N)';
        x = kron(v,ones(K,1)).*x;
        %% Alg.5    
        R_robust = Spiked_model(x,m,tol);
        
        [U V] = eig(R_robust);
        [V map] = sort(diag(V),'descend');
        U = U(:,map);
        [U r] = qr(U);
        Ec_Robust = U(:,1:m);
        err_robust_subspace(iter,t) = norm(Ec_Robust*inv(Ec_Robust'*Ec_Robust)*Ec_Robust'-Ec_true*Ec_true','fro');
        err_robust(iter,t) = norm(R_true/trace(R_true)-R_robust/trace(R_robust),'fro')^2/norm(R_true/trace(R_true),'fro')^2;
        
        
        
        %% estimate by Tyler M estimator
        R_Tyler = Tyler_estimator(x,tol);
        
        [U V] = eig(R_Tyler);
        [V map] = sort(diag(V),'descend');
        U = U(:,map);
        [U r] = qr(U);
        % construct signal subspace
        Ec_Tyler = U(:,1:m);
        err_Tyler_subspace(iter,t) = norm(Ec_Tyler*inv(Ec_Tyler'*Ec_Tyler)*Ec_Tyler'-Ec_true*Ec_true','fro');
        err_Tyler(iter,t) =  norm(R_true/trace(R_true)-R_Tyler/trace(R_Tyler),'fro')^2/norm(R_true/trace(R_true),'fro')^2;
        
        %% two-step estimate: Tyler + projection
        sigma_Tyler = sum(V(m+1:end))/(K-m);
        p_Tyler = V(1:m)-sigma_Tyler;
        Un = U(:,1:m);
        R_Tyler_project = Un*diag(p_Tyler)*Un' + sigma_Tyler*eye(K);
        err_Tyler_projected(iter,t) =  norm(R_true/trace(R_true)-R_Tyler_project/trace(R_Tyler_project),'fro')^2/norm(R_true/trace(R_true),'fro')^2;
        
    end
end


%%
errTyler_project_mean = mean(err_Tyler_projected,2);
errTyler_mean = mean(err_Tyler,2);
errMM_mean = mean(err_robust,2);
plot(Ngrid,errTyler_mean,'r+ --',Ngrid,errTyler_project_mean,'m+ -.',Ngrid,errMM_mean,'k*:','Linewidth',1);
legend('Tyler','Tyler+Projection','Constrained Tyler');
xlabel('Number of Samples');
ylabel('Estimation Error (NMSE)');
title(['Spiked Structure (L=' num2str(m) ', K=' num2str(K) ')'] );

figure
errTyler_mean_subspace = mean(err_Tyler_subspace,2);
errMM_mean_subspace = mean(err_robust_subspace,2);
plot(Ngrid,errTyler_mean_subspace,'r+ --',Ngrid,errMM_mean_subspace,'k*:','Linewidth',1);
legend('Tyler','Constrained Tyler');
xlabel('Number of Samples');
ylabel('Estimation Error (subspace)');
title(['Spiked Structure (L=' num2str(m) ', K=' num2str(K) ')'] );
