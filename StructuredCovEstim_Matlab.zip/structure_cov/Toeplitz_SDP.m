% Description: This code implements Toeplitz structured covariance matrix 
%              estimation using Alg. 1 [1]. Requires installation of CVX
%              [2],[3].

% Input:
%   x:         K-by-N data matrix
% 	tol:       convergence tolerance

% Output:
%   R:         K-by-K matrix. Estimated covariance matrix with Toeplitz structure
% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                  "Robust Estimation of Structured Covariance Matrix for
%                   Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                   vol. 64, no. 14, pp. 3576-3590, July 2016.
%              [2] Michael Grant and Stephen Boyd. CVX: Matlab software for
%                  disciplined convex programming, version 2.0 beta.
%                  http://cvxr.com/cvx, September 2013.
%              [3] Michael Grant and Stephen Boyd. Graph implementations
%                  for nonsmooth convex programs, Recent Advances in Learning
%                  and Control (a tribute to M. Vidyasagar), V. Blondel, S.
%                  Boyd, and H. Kimura, editors, pages 95-110, Lecture Notes
%                  in Control and Information Sciences, Springer, 2008.
%                  http://stanford.edu/~boyd/graph_dcp.html.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun   
% Date:        02/19/2017
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.


function [R] = Toeplitz_SDP(x,tol)
Converge = 0;
% initialization
[K N] = size(x);
tmp = rand(K,1000);
R = tmp*tmp';
R = R/trace(R);

f_previous = ObjVal(x,R);
itr_R = 0;
while(~Converge)
    itr_R = itr_R+1;
    w = 1./(diag(x'*inv(R)*x));
    M = K/N*x*diag(w)*x';
    cvx_begin quiet
    variable X(K,K) toeplitz
    variable S(K,K)
    minimize (trace(inv(R)*X)+trace(M*S))
    subject to
    [S eye(K);eye(K) X]==semidefinite(2*K);
    cvx_end
    X = X/trace(X);
    f_current = ObjVal(x,X);
    Converge = abs(f_current-f_previous)/max(1,abs(f_previous))<tol;
    R = X;
    f_previous = f_current;
end
end