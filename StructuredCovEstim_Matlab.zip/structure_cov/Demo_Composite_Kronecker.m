% Description: Implementation of Fig. 11 in [1]. 
% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                  "Robust Estimation of Structured Covariance Matrix for
%                   Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                   vol. 64, no. 14, pp. 3576-3590, July 2016.
%              [2] Michael Grant and Stephen Boyd. CVX: Matlab software for
%                  disciplined convex programming, version 2.0 beta.
%                  http://cvxr.com/cvx, September 2013.
%              [3] Michael Grant and Stephen Boyd. Graph implementations
%                  for nonsmooth convex programs, Recent Advances in Learning
%                  and Control (a tribute to M. Vidyasagar), V. Blondel, S.
%                  Boyd, and H. Kimura, editors, pages 95-110, Lecture Notes
%                  in Control and Information Sciences, Springer, 2008.
%                  http://stanford.edu/~boyd/graph_dcp.html.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun  
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.

clear
p = 10;
q = 8;


% True parameters
beta = 0.8;
c = beta.^abs([1:q]'-1);
r = beta.^abs(1-[1:q]);
B0 = toeplitz(c,r);
tmp = randn(p,2*p);
tmp = tmp*tmp';
A0 = tmp/trace(tmp);
A0 = eye(p);
R0 = kron(A0,B0);

Ngrid = 10:5:50;
repts = 10;
itrN = 0;
for N = Ngrid
    fprintf('sample number:%d\n',N);
    itrN = itrN + 1;
    for i = 1:repts
        % generate normal distributed samples
        v = sqrt(chi2rnd(1,[1,N]));
        x = mvnrnd(zeros(p*q,1),R0,N)';
        x = kron(v,ones(p*q,1)).*x;        
        [err_single_structure(itrN,i),err_double_structure(itrN,i)]=CompareEstimators(p,q,N,x,R0);
    end
end
err_single_structure = sum(err_single_structure,2)/repts;
err_double_structure = sum(err_double_structure,2)/repts;

plot(Ngrid,err_single_structure,'b+-',Ngrid,err_double_structure,'r.-.');
legend('Kronecker','Kronecker+Toeplitz')
xlabel('Number of Samples');
ylabel('Estimation Error (NMSE)');
