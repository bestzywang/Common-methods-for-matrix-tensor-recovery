% Description: Implementation of Fig. 5(a) in [1]. Running the code
%              requires installation of CVX [2],[3].
% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                  "Robust Estimation of Structured Covariance Matrix for
%                   Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                   vol. 64, no. 14, pp. 3576-3590, July 2016.
%              [2] Michael Grant and Stephen Boyd. CVX: Matlab software for
%                  disciplined convex programming, version 2.0 beta.
%                  http://cvxr.com/cvx, September 2013.
%              [3] Michael Grant and Stephen Boyd. Graph implementations
%                  for nonsmooth convex programs, Recent Advances in Learning
%                  and Control (a tribute to M. Vidyasagar), V. Blondel, S.
%                  Boyd, and H. Kimura, editors, pages 95-110, Lecture Notes
%                  in Control and Information Sciences, Springer, 2008.
%                  http://stanford.edu/~boyd/graph_dcp.html.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun   
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.

%%
clc
clear

K = 15;

beta = 0.4;
c = beta.^abs([1:K]'-1);
r = beta.^abs(1-[1:K]);
R_true = toeplitz(c,r);

L = 2*K+1;
tol = 1e-6;

Ngrid = 20:20:200;
bandwidth = [1 3 5 7];
repts = 10;

itrN = 0;
for N = Ngrid
    itrN = itrN + 1;
    for t = 1:repts
        % generate samples
        v = sqrt(chi2rnd(1,[1,N]));
        x = mvnrnd(zeros(K,1),R_true,N)';
        x = kron(v,ones(K,1)).*x;
        itr_k = 0;
        
        % banded Toeplitz regularization
        for k = bandwidth
            fprintf('sample number:%d, repetition number:%d, bandwidth:%d\n',N,t,k);
            
            itr_k = itr_k + 1;
            R_banded_circ = BandedToeplitz_circ(x,k,L,tol);
            err_banded_N(itr_k,t) = norm(R_true/trace(R_true)-R_banded_circ/trace(R_banded_circ),'fro')^2/norm(R_true/trace(R_true),'fro')^2;
            
        end
        
        % Toeplitz regularization
        fprintf('sample number:%d, repetition number:%d, bandwidth:%d\n',N,t,K-1);
        R_circ = Toeplitz_Circ(x,L,tol);       
        err_CirApp_N(t) = norm(R_true/trace(R_true)-R_circ/trace(R_circ),'fro')^2/norm(R_true/trace(R_true),'fro')^2;
        
    end
    err_banded(:,itrN) = mean(err_banded_N,2);
    err_CirApp(itrN) = mean(err_CirApp_N);
end
plot(Ngrid,err_banded(1,:),'b.-',Ngrid,err_banded(2,:),'r*--',Ngrid,err_banded(3,:),'go:',Ngrid,err_banded(4,:),'m.-.',Ngrid,err_CirApp,'k-');
legend('k=1','k=3','k=5','k=7','Unbanded');
xlabel('Number of Samples')
ylabel('Estimation Error (NMSE)')
title('Regularization by banding (\beta = 0.4)')