% Description:     This code implements covariance estimation for Kronecker structure
%                  using Alg. 7 [1].

% Input:
%     x:           K-by-N data matrix
%     p:           size of A
%     q:           size of B
%   tol:           convergence tolerance
%   An (optional): K-by-K matrix. Inital value of A
%   Bn (optional): K-by-K matrix. Inital value of B

% Output:
%   Rn:            K-by-K matrix. Estimated covariance matrix with Kronecker structure

% Reference:       [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                      "Robust Estimation of Structured Covariance Matrix for
%                       Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                       vol. 64, no. 14, pp. 3576-3590, July 2016.
%                  [2] Michael Grant and Stephen Boyd. CVX: Matlab software for
%                      disciplined convex programming, version 2.0 beta.
%                      http://cvxr.com/cvx, September 2013.
%                  [3] Michael Grant and Stephen Boyd. Graph implementations
%                      for nonsmooth convex programs, Recent Advances in Learning
%                      and Control (a tribute to M. Vidyasagar), V. Blondel, S.
%                      Boyd, and H. Kimura, editors, pages 95-110, Lecture Notes
%                      in Control and Information Sciences, Springer, 2008.
%                      http://stanford.edu/~boyd/graph_dcp.html.
% Link:            http://www.danielppalomar.com/publications.html
% Author:          Ying Sun   
% Date:            02/19/2017 
% Note:            Please contact <sun578@purdue.edu> for any problem related
%                  to this code.

function [R] = kronecker_structure(x,p,q,tol,An,Bn)
[K,N] = size(x);
% generate samples Mi
for i = 1:N
    M(:,:,i)=reshape(x(:,i),q,p);
end

if(isempty(An))
    tmp = rand(p,K+100);
   An = tmp*tmp';
   An = An/trace(An);
end

if(isempty(Bn))
    tmp = rand(q,K+100);
   Bn = tmp*tmp';
   Bn = Bn/trace(Bn);
end

Converge = 0;

while(~Converge)
    % fix A update B
    w = 1./(diag(x'*inv(kron(An,Bn))*x));
    B=0;
    for i = 1:N
        B =B+M(:,:,i)*inv(An)*M(:,:,i)'*w(i);
    end
    B = B*q/N;

    % smoothing B by Karcher mean
    B = sqrtm(Bn)*sqrtm(inv(sqrtm(Bn))*B*inv(sqrtm(Bn)))*sqrtm(Bn);
    Converge = norm(B-Bn,'fro')<tol;
    Bn = B;

    % fix B update A
    w = 1./(diag(x'*inv(kron(An,Bn))*x));
    A=0;
    for i = 1:N
        A =A+M(:,:,i)'*inv(Bn)*M(:,:,i)*w(i);
    end
    A = A*p/N;

    A = sqrtm(An)*sqrtm(inv(sqrtm(An))*A*inv(sqrtm(An)))*sqrtm(An);
    An = A;
end
    R = kron(An,Bn);
end