% Description:    This function compares the estimator accuracy by imposing
%                 only Kronecker structure and imposing both Kronecker and 
%                 Toeplitz structure.

% Input
%     p:           size of A
%     q:           size of B
%     N:           sample size
%     x:           K-by-N data matrix
%    R0:           K-by-K matrx. True covariance. 

% Output:
%   err_single_structure: 
%                  NMSE of Kronecker structured estimator
%   err_double_structure: 
%                  NMSE of Kronecker+Toeplitz structured estimator

% Reference:      [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                     "Robust Estimation of Structured Covariance Matrix for
%                     Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                     vol. 64, no. 14, pp. 3576-3590, July 2016.
% Link:           http://www.danielppalomar.com/publications.html
% Author:         Ying Sun   
% Date:           02/19/2017 
% Note:           Please contact <sun578@purdue.edu> for any problem related
%                 to this code.

function [err_single_structure,err_double_structure]=CompareEstimators(p,q,N,x,R0)
% generate samples Mi
for i = 1:N
    M(:,:,i)=reshape(x(:,i),q,p);
end

% initialize A and B
tmp = rand(p,100);
A_n_in = tmp*tmp';
A_n_in = A_n_in/trace(A_n_in);
tmp = rand(q,100);
B_n_in = tmp*tmp';
B_n_in = B_n_in/trace(B_n_in);
A_n_out = A_n_in;
B_n_out = B_n_in;
Rtmp = kron(A_n_in,B_n_in);

A1_n_in = A_n_in;
B1_n_in = B_n_in;

tol = 1e-4;

Converge = 0;

while(~Converge)
    % fix A update B
    w = 1./(diag(x'*inv(kron(A1_n_in,B1_n_in))*x));
    Q=0;
    for i = 1:N
        Q =Q+M(:,:,i)*inv(A1_n_in)*M(:,:,i)'*w(i);
    end
    Q = Q*q/N; 
    % solving inner problem using circulant embedding 
    L = 2*q-1;
    F = [eye(q) zeros(q,L-q)]*dftmtx(L)/sqrt(L);
    B_inv = inv(B1_n_in);
    w = diag(F'*B_inv*F);           
    r_int = rand(L-1,1);
    r_int = (r_int+flipud(r_int))/2;
    r_int = [rand(1); r_int];
    r = r_int;
    Converge_r = 0;
    itr_r = 0;
    while(~Converge_r)
        itr_r = itr_r+1;    
    R = F*diag(r)*F';
    D = diag(F'*inv(R)*Q*inv(R)*F);
    s = r.*D.*r;    
    rtmp = sqrt(s./(w));
    Converge_r = (norm(rtmp-r)<tol);
%           hold on
%           plot(itr_r,w'*r+trace(Q*inv(R)),'ro')
        r = rtmp;  
    end
    B = R;
    Converge = norm(B-B1_n_in,'fro')<tol;
    %B1_n_in = B/trace(B);
    B1_n_in = B;
    Rtmp = kron(A1_n_in,B1_n_in);

    % fix B update A
    w = 1./(diag(x'*inv(kron(A1_n_in,B1_n_in))*x));
    A=0;
    for i = 1:N
        A =A+M(:,:,i)'*inv(B1_n_in)*M(:,:,i)*w(i);
    end
    A = A*p/N;
    

    A = sqrtm(A1_n_in)*sqrtm(inv(sqrtm(A1_n_in))*A*inv(sqrtm(A1_n_in)))*sqrtm(A1_n_in);
    A1_n_in = A;
    Rtmp = kron(A1_n_in,B1_n_in);

end
R_double = kron(A1_n_in,B1_n_in);
err_double_structure = norm(R0/trace(R0)-R_double/trace(R_double),'fro')^2/norm(R0/trace(R0),'fro')^2;

% kronecker structure only
R_single = kronecker_structure(x,p,q,tol,A1_n_in,B1_n_in);
err_single_structure = norm(R0/trace(R0)-R_single/trace(R_single),'fro')^2/norm(R0/trace(R0),'fro')^2;
end