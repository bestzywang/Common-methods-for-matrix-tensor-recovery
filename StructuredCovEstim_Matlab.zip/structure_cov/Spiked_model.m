% Description: This code implements covariance estimation for spiked structure
%              using Alg. 5 [1].

% Input:
%   x:         K-by-N data matrix
%   m:         number of spikes
%   tol:       convergence tolerance
%
% Output:
%   Rn:        K-by-K matrix. Estimated covariance matrix with spiked structure
% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                  "Robust Estimation of Structured Covariance Matrix for
%                   Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                   vol. 64, no. 14, pp. 3576-3590, July 2016.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun   
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.

function [Rn] = Spiked_model(x,m,tol)
[K,N] = size(x);
Converge = 0;

tmp = randn(K,1000);
Rn = tmp*tmp';
itr = 0;
while(~Converge)
    f_previous = ObjVal(x,Rn);
    itr = itr + 1;
    
    w = 1./(diag(x'*inv(Rn)*x));
    M = K/N*x*diag(w)*x';
    
    [U V] = eig(M);
    [V_sort map] = sort(diag(V),'descend');
    U = U(:,map);
    [U r] = qr(U);
    sigma0 = sum(V_sort(m+1:end))/(K-m);
    p = V_sort(1:m)-sigma0;
    Un = U(:,1:m);
    R_robust = Un*diag(p)*Un' + sigma0*eye(K);
    R_robust = R_robust/trace(R_robust);
    f_current = ObjVal(x,R_robust);
    
    Converge = abs(f_current-f_previous)/max(1,abs(f_previous))<tol;
    Rn = R_robust;
end

end