% Description: This code implements Toeplitz structured covariance matrix 
%              estimation using Alg. 3 (circlulant embedding) [1].

% Input:
%   x:         K-by-N data matrix
%   L:         number of spikes
% 	tol:       convergence tolerance

% Output:
%   Rtmp:      K-by-K matrix. Estimated covariance matrix with Toeplitz structure

% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                  "Robust Estimation of Structured Covariance Matrix for
%                   Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                   vol. 64, no. 14, pp. 3576-3590, July 2016.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun   
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.

function [Rtmp] = Toeplitz_Circ(x,L,tol)
[K N] = size(x);
% initialization
p_int = rand(L-1,1);
p_int = (p_int+flipud(p_int))/2;
p_int = [rand(1); p_int];
p = p_int;

F = [eye(K) zeros(K,L-K)]*dftmtx(L)/sqrt(L);

Converge = 0;
itr_p = 0;
f_previous = ObjVal(x,F*diag(p)*F');
while(~Converge)
    itr_p = itr_p+1;
    % calculate R_t
    R = F*diag(p)*F';
    R_ivs = inv(R);
    w = diag(F'*R_ivs*F);
    M = K/N*x*diag(1./(diag(x'*R_ivs*x)))*x';
    D = diag(F'*R_ivs*M*R_ivs*F);
    s = p.*D.*p;
    
    ptmp = sqrt(s./(w));
    Rtmp = real(F*diag(ptmp)*F');
    f_current = ObjVal(x,Rtmp);
    ptmp = ptmp/trace(Rtmp);
    
    Converge = abs(f_current-f_previous)/max(1,abs(f_previous))<tol;
    
    p = ptmp;
    f_previous = f_current;
end
end