function [f] = ObjVal(x,R)
[K N] = size(x);
f = log(det(R))+K/N*sum(log(diag(x'*inv(R)*x)));
end