% Description: This code implements banded Toepiltz structured covariance estimation
%              using Alg. 4 in [1]. Running the code requires installation
%              of CVX [2],[3].
% Input:
%     x:       K-by-N data matrix
%     k:       bandwidth
%     L:       number of spikes
%     tol:     convergence tolerance

% Output:      
%   Rtmp:      K-by-K matrix. Estimated covariance matrix with banded Toeplitz structure

% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                  "Robust Estimation of Structured Covariance Matrix for
%                   Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                   vol. 64, no. 14, pp. 3576-3590, July 2016.
%              [2] Michael Grant and Stephen Boyd. CVX: Matlab software for
%                  disciplined convex programming, version 2.0 beta.
%                  http://cvxr.com/cvx, September 2013.
%              [3] Michael Grant and Stephen Boyd. Graph implementations
%                  for nonsmooth convex programs, Recent Advances in Learning
%                  and Control (a tribute to M. Vidyasagar), V. Blondel, S.
%                  Boyd, and H. Kimura, editors, pages 95-110, Lecture Notes
%                  in Control and Information Sciences, Springer, 2008.
%                  http://stanford.edu/~boyd/graph_dcp.html.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun   
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.


function [Rtmp] = BandedToeplitz_circ(x,k,L,tol)
if (mod(L,2)~=1)
    error('This implementation requires L being odd')
end
[K,N] = size(x);
Converge = 0;

p = rand(L-1,1);
p = (p+flipud(p))/2;
p = [rand(1);p];
F = [eye(K) zeros(K,L-K)]*dftmtx(L)/sqrt(L);
itr_p = 0;
F_bar = [zeros(K-k-1,k+1),eye(K-k-1)]*F;
F_bar = real([sqrt(2)*(F_bar(:,1)),2*F_bar(:,2:1+ceil((L-1)/2))]);

while(~Converge)
    itr_p = itr_p+1;
    % calculate R_t
    R = F*diag(p)*F';
    f_previous = ObjVal(x,R);
    R_ivs = inv(R);
    w = diag(F'*R_ivs*F);
    M = K/N*x*diag(1./(diag(x'*R_ivs*x)))*x';
    S = diag(p)*F'*R_ivs*M*R_ivs*F*diag(p);
    s = real(diag(S));
    p_old = p;
    
    w = real([sqrt(2)*w(1);2*w(2:1+ceil((L-1)/2))]);
    s = real([s(1)/sqrt(2);2*s(2:1+ceil((L-1)/2))]);
    
    cvx_begin quiet
    variable p1(1+ceil((L-1)/2),1)
    minimize (w'*p1+sum(s.*inv_pos(p1)))
    subject to
    F_bar*p1 == 0
    cvx_end
    
    p = [p1(1)*sqrt(2);p1(2:1+ceil((L-1)/2));flipud(p1(2:1+ceil((L-1)/2)))];
    Rtmp = F*diag(p)*F';
    f_current = ObjVal(x,Rtmp);
    p = p/Rtmp(end);
    
    Converge = abs(f_current-f_previous)/max(1,abs(f_previous))<tol;
end
end