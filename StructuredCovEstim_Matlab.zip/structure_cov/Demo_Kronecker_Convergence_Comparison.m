% Description: Implementation of Fig. 10 in [1]. This code demostrates the
%              objective value evolution of estimating Kronecker structured 
%              covariance matrix using Alg. 6 and 7. 
% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar,
%                  "Robust Estimation of Structured Covariance Matrix for
%                   Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                   vol. 64, no. 14, pp. 3576-3590, July 2016.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun   
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.

%%
clear
p = 10;
q = 8;
N = 4;

% True parameters
beta = 0.8;
c = beta.^abs([1:q]'-1);
r = beta.^abs(1-[1:q]);
B0 = toeplitz(c,r);
tmp = randn(p,2*p);
A0 = eye(p);
R0 = kron(A0,B0);

% generate normal distributed samples
v = sqrt(chi2rnd(1,[1,N]));
x = mvnrnd(zeros(p*q,1),R0,N)';
x = kron(v,ones(p*q,1)).*x;

% generate samples Mi
for i = 1:N
    M(:,:,i)=reshape(x(:,i),q,p);
end

% initialize A and B
tmp = rand(p,100);
A_n_in = tmp*tmp';
A_n_in = A_n_in/trace(A_n_in);
tmp = rand(q,100);
B_n_in = tmp*tmp';
B_n_in = B_n_in/trace(B_n_in);
A_n_out = A_n_in;
B_n_out = B_n_in;
Rtmp = kron(A_n_in,B_n_in);

A1_n_in = A_n_in;
B1_n_in = B_n_in;

f_BCD = log(det(Rtmp))+p*q/N*sum(log(diag(x'*inv(Rtmp)*x)));
tol = 1e-6;
Converge = 0;

%% BCD: Alg.6
while(~Converge)
    ConvergeB = 0;
    while (~ConvergeB)
        % fix A update B
        w = 1./(diag(x'*inv(kron(A_n_in,B_n_in))*x));
        B=0;
        for i = 1:N
            B =B+M(:,:,i)*inv(A_n_in)*M(:,:,i)'*w(i);
        end
        B = B*q/N;
        B = B/trace(B);
        Rtmp = kron(A_n_in,B);
        f_BCD = [f_BCD;log(det(Rtmp))+p*q/N*sum(log(diag(x'*inv(Rtmp)*x)))];
        B_n_in = B;
        ConvergeB = abs(f_BCD(end)-f_BCD(end-1))/max(1,abs(f_BCD(end-1)))<tol;
    end
    f_A = f_BCD(end);
    
    ConvergeA = 0;
    while(~ConvergeA)
        % fix B update A
        w = 1./(diag(x'*inv(kron(A_n_in,B_n_in))*x));
        A=0;
        for i = 1:N
            A =A+M(:,:,i)'*inv(B_n_in)*M(:,:,i)*w(i);
        end
        A = A*p/N;
        A = A/trace(A);
        Rtmp = kron(A,B_n_in);
        f_BCD = [f_BCD;log(det(Rtmp))+p*q/N*sum(log(diag(x'*inv(Rtmp)*x)))];
        A_n_in = A;
        ConvergeA = abs(f_BCD(end)-f_BCD(end-1))/max(1,abs(f_BCD(end-1)))<tol;
    end
    f_B = f_BCD(end);
    Converge = abs(f_B-f_A)/max(1,f_A)<tol;
    A_n_out = A_n_in;
    B_n_out = B_n_in;
end


%% Block Alternating MM: Alg.7
Converge = 0;
f_BSUM = f_BCD(1);
while(~Converge)
    % fix A update B
    w = 1./(diag(x'*inv(kron(A1_n_in,B1_n_in))*x));
    B=0;
    for i = 1:N
        B =B+M(:,:,i)*inv(A1_n_in)*M(:,:,i)'*w(i);
    end
    B = B*q/N;
    % smoothing B by Karcher mean
    B = sqrtm(B1_n_in)*sqrtm(inv(sqrtm(B1_n_in))*B*inv(sqrtm(B1_n_in)))*sqrtm(B1_n_in);

    B1_n_in = B;
    Rtmp = kron(A1_n_in,B1_n_in);
    f_BSUM = [f_BSUM,log(det(Rtmp))+p*q/N*sum(log(diag(x'*inv(Rtmp)*x)))];
    % fix B update A
    w = 1./(diag(x'*inv(kron(A1_n_in,B1_n_in))*x));
    A=0;
    for i = 1:N
        A =A+M(:,:,i)'*inv(B1_n_in)*M(:,:,i)*w(i);
    end
    A = A*p/N;
    A = sqrtm(A1_n_in)*sqrtm(inv(sqrtm(A1_n_in))*A*inv(sqrtm(A1_n_in)))*sqrtm(A1_n_in);
    A1_n_in = A;
    Rtmp = kron(A1_n_in,B1_n_in);
    f_BSUM = [f_BSUM,log(det(Rtmp))+p*q/N*sum(log(diag(x'*inv(Rtmp)*x)))];
    Converge = abs(f_BSUM(end)-f_BSUM(end-1))/max(1,abs(f_BSUM(end-1)))<tol;
end

plot(1:length(f_BCD),f_BCD,'b-',1:length(f_BSUM),f_BSUM,'r--');
xlabel('Iteration');
ylabel('Objective Value');
legend('Algorithm 6 (Gauss-Seidel)','Algorithm 7 (Block MM)');