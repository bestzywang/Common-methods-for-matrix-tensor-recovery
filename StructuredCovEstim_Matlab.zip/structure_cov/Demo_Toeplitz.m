% Description: Comparison of sample covariance matrix and Toeplitz
%              structured Tyler's estimator (see Fig. 2 in [1]). Running
%              the code requires installation of CVX [2],[3].
% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                  "Robust Estimation of Structured Covariance Matrix for
%                   Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                   vol. 64, no. 14, pp. 3576-3590, July 2016.
%              [2] Michael Grant and Stephen Boyd. CVX: Matlab software for
%                  disciplined convex programming, version 2.0 beta.
%                  http://cvxr.com/cvx, September 2013.
%              [3] Michael Grant and Stephen Boyd. Graph implementations
%                  for nonsmooth convex programs, Recent Advances in Learning
%                  and Control (a tribute to M. Vidyasagar), V. Blondel, S.
%                  Boyd, and H. Kimura, editors, pages 95-110, Lecture Notes
%                  in Control and Information Sciences, Springer, 2008.
%                  http://stanford.edu/~boyd/graph_dcp.html.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun   
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.
%%
clc
clear

K = 15;
tol = 1e-6;
beta = 0.8;
c = beta.^abs([1:K]'-1);
r = beta.^abs(1-[1:K]);
R_true = toeplitz(c,r);
R_true = R_true/trace(R_true);

Ngrid = 20:20:200;

iter = 0;
repts = 10;
for N = Ngrid
    iter = iter + 1;
    for t = 1:repts
    fprintf('sample number: %d, repetition time: %d\n',N,t)
    L = 2*K+1;
    % Generate samples
    v = sqrt(chi2rnd(1,[1,N]));
    x = mvnrnd(zeros(K,1),R_true,N)';
    x = kron(v,ones(K,1)).*x;

    %% SCM
    R_SCM = 1/N*(x*x');
    err_SCM(iter,t) = norm(R_true/trace(R_true)-R_SCM/trace(R_SCM),'fro')^2/norm(R_true/trace(R_true),'fro')^2;
    
    %% Toeplitz structure (SDP Alg.1)
    R_SDP = Toeplitz_SDP(x,tol);    
    err_SDP(iter,t) = norm(R_true/trace(R_true)-R_SDP/trace(R_SDP),'fro')^2/norm(R_true/trace(R_true),'fro')^2;
    
    %% Toeplitz structure (Circulant embedding Alg.3)
    R_circ = Toeplitz_Circ(x,L,tol);    
    err_CirApp(iter,t) = norm(R_true/trace(R_true)-R_circ/trace(R_circ),'fro')^2/norm(R_true/trace(R_true),'fro')^2;
    end
end

err_SCM = sum(err_SCM,2)/repts;
err_SDP = sum(err_SDP,2)/repts;
err_CirApp = sum(err_CirApp,2)/repts;

semilogy(Ngrid,err_SCM,'b.-',Ngrid,err_SDP,'co-',Ngrid,err_CirApp,'k:^','linewidth',1)
legend('SCM','Constrained Tyler (Sequential SDP)','Constrained Tyler (Circulant embedding)');
xlabel('Number of Samples');
ylabel('Estimation Error (NMSE)');
title(['Toeplitz Structure (\beta = 0.8),' num2str(repts), ' repetions'])



