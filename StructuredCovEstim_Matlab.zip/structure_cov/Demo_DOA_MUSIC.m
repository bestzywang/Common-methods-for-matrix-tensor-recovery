% Description: Implementation of Fig. 6 in [1]. Running the code
%              requires installation of CVX [2],[3].
% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar, 
%                  "Robust Estimation of Structured Covariance Matrix for
%                   Heavy-Tailed Elliptical Distributions," IEEE Trans. on Signal Processing,
%                   vol. 64, no. 14, pp. 3576-3590, July 2016.
%              [2] Michael Grant and Stephen Boyd. CVX: Matlab software for
%                  disciplined convex programming, version 2.0 beta.
%                  http://cvxr.com/cvx, September 2013.
%              [3] Michael Grant and Stephen Boyd. Graph implementations
%                  for nonsmooth convex programs, Recent Advances in Learning
%                  and Control (a tribute to M. Vidyasagar), V. Blondel, S.
%                  Boyd, and H. Kimura, editors, pages 95-110, Lecture Notes
%                  in Control and Information Sciences, Springer, 2008.
%                  http://stanford.edu/~boyd/graph_dcp.html.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun   
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.

%% 
clc
clear
N = 20;
K = 15;

sigma0 = 0.1; % noise variance

m  = 5; % number of signals
theta_signal = [-10 10 15 35 40];
DoA_degree = theta_signal/360*2*pi;

% steering vectors corresponds to the signal
for l = 1:m
    A_signal(:,l) = exp(-1i.*pi.*[0:K-1].*sin(DoA_degree(l))).';
end

p = ones(m,1);
R_true = A_signal*diag(p)*A_signal'+sigma0*eye(K);
% Generate samples
v = chi2rnd(1,[1,N]);
x = mvnrnd(zeros(K,1),R_true,N)';
x = kron(v,ones(K,1)).*x;

% create steering vectors
delta = 5;
L = 180/delta; % angle resolution
theta = -90:delta:(90-delta);
theta = theta/360*2*pi;
A = zeros(K,L);

for l = 1:L
    A(:,l) = exp(-1i.*pi.*[0:K-1].*sin(theta(l))).';
end


%% estimate by SCM
R_SCM = 1/N*x*x';
[U V] = eig(R_SCM);
[V1 map] = sort(diag(V),'descend');
U1 = U(:,map);
[U1 r] = qr(U1);
% construct noise subspace
Ec_SCM = U1(:,m+1:K);


%% estimate by COCA
cvx_begin   quiet
variable R0(K,K) hermitian
variables d(N,1) sigma_coca
variable p0(L,1)
minimize (norm(R0-1/N*x*diag(d)*x','fro'))
subject to
for i = 1:N
    (R0-1/K*d(i)*x(:,i)*x(:,i)') == hermitian_semidefinite(K);
end
d >= 0;
sigma_coca >= 0;
p0 >= 0;
R0 == A*diag(p0)*A' + sigma_coca*eye(K);
trace(R0)==1;
cvx_end

[U V] = eig(R0);
[V1 map] = sort(diag(V),'descend');
U1 = U(:,map);
[U1 r] = qr(U1);
% construct noise subspace
Ec_COCA = U1(:,m+1:K);

%% estimate p by Alg. 2
Converge = 0;
itr_p = 0;
F = [A eye(K)];
p = rand(L+K,1);
tol = 1e-4;
while(~Converge)
    itr_p = itr_p+1;
    % calculate R_t
    R = F*diag(p)*F';
    f_previous = ObjVal(x,R);
    R_ivs = inv(R);
    w = diag(F'*R_ivs*F);
    M = K/N*x*diag(1./(diag(x'*R_ivs*x)))*x';
    D = diag(F'*R_ivs*M*R_ivs*F);
    D = p.*D.*p;
    ptmp(1:L,1) = (sqrt(D(1:L)./w(1:L)));
    ptmp(L+1:L+K,1) = ones(K,1)*sqrt(sum(D(L+1:L+K))/sum(w(L+1:L+K)));
    Rtmp = F*diag(ptmp)*F';
    ptmp = ptmp/trace(Rtmp);
    f_current = ObjVal(x,Rtmp);
    Converge = abs(f_current-f_previous)/max(1,abs(f_previous))<tol;
    p = ptmp;
end

[U V] = eig(Rtmp);
[V1 map] = sort(diag(V),'descend');
U1 = U(:,map);
[U1 r] = qr(U1);
% construct noise subspace
Ec = U1(:,m+1:K);


%% estimate by Tyler M estimator
Converge = 0;
Rint = randn(K,1000);
R1 = Rint*Rint';
R1n = R1/trace(R1);

while(~Converge)
    wi = 1./(diag(x'*inv(R1n)*x));
    R1 = (K)/N*(x)*diag(wi)*(x)';
    Converge = (norm(R1-R1n,'fro')<tol);
    R1n = R1;
end
[U V] = eig(R1);
[V1 map] = sort(diag(V),'descend');
U1 = U(:,map);
[U1 r] = qr(U1);
% construct noise subspace
Ec_Tyler = U1(:,m+1:K);

%% compute pseudospectrum
itr = 0;
resol = 0.1;
T1 = -100:resol:(100-resol);
T = T1/360*2*pi;
for t = T
    itr = itr + 1;
    a = exp(-1i.*pi.*[0:K-1].*sin(t)).';
    P_theta_robust(itr) = 20*log10((a'*Ec*inv(Ec'*Ec)*Ec'*a)^-1);
    P_theta_SCM(itr) = 20*log10((a'*(Ec_SCM*inv(Ec_SCM'*Ec_SCM)*Ec_SCM')*a)^-1);
    P_theta_Tyler(itr) = 20*log10((a'*(Ec_Tyler*inv(Ec_Tyler'*Ec_Tyler)*Ec_Tyler')*a)^-1);
    P_theta_COCA(itr) = 20*log10((a'*(Ec_COCA*inv(Ec_COCA'*Ec_COCA)*Ec_COCA')*a)^-1);
end
hold on
plot(T1,real(P_theta_robust),'k-',T1,real(P_theta_COCA),'m-',T1,real(P_theta_Tyler),'r-',T1,real(P_theta_SCM),'b-','linewidth',1);
h = stem(theta_signal,ones(m,1)*max(real([P_theta_robust P_theta_SCM P_theta_Tyler P_theta_COCA])),'m.:');
set(h,'BaseValue',min(real([P_theta_robust P_theta_SCM P_theta_Tyler P_theta_COCA])));
legend('Constrained Tyler','COCA (SDP)','Tyler','SCM')
xlabel('Angle (deg)');
ylabel('Pseudospectrumn');
title(['Snapshot N=' num2str(N) ', \sigma=' num2str(sigma0)]);
xlim([-20 60])
