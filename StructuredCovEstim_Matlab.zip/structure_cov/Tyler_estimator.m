% Description:  This code implements Tyler's robust covariance estimator [1].

% Input:
%   x:          K-by-N data matrix
%   tol:        convergence tolerance
% Reference:    [1] D. E. Tyler, "A distribution-free M-estimator of
%                   multivariate scatter," Ann. Statist., vol. 15, no. 1, 
%                   pp. 234-251, 03 1987.

% Author:      Ying Sun   
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.

function [Rn]  = Tyler_estimator(x,tol)
[K,N] = size(x);
Converge = 0;
Rint = randn(K,1000);
R = Rint*Rint';
Rn = R/trace(R);
while(~Converge)
    f_previous = ObjVal(x,Rn);
    wi = 1./(0+diag(x'*inv(Rn)*x));
    R = (K)/N*(x)*diag(wi)*(x)';
    f_current = ObjVal(x,R);    
    Converge = abs(f_current-f_previous)/max(1,abs(f_previous))<tol;
    Rn = R/trace(R);
end
end